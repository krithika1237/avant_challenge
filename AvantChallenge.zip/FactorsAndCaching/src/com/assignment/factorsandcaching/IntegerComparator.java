package com.assignment.factorsandcaching;

import java.util.Comparator;

public class IntegerComparator implements Comparator<Integer> {
    @Override
    public int compare(Integer o1, Integer o2) {
        // TODO Auto-generated method stub
        return o2.compareTo(o1);
    }
}
