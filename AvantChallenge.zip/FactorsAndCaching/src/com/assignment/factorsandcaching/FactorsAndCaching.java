package com.assignment.factorsandcaching;

import java.util.ArrayList;
import java.util.Arrays;

import java.util.Hashtable;
import java.util.Iterator;

public class FactorsAndCaching {

    // hashtable of input array with array values as key and value.Ex: 10->10, 5->5 etc.
    private static Hashtable<Integer, Integer> arrayValuesTable = new Hashtable<Integer, Integer>();

    private static Hashtable<Integer, Integer> cachingTable = new Hashtable<Integer, Integer>();
    private static Hashtable<Integer, ArrayList<Integer>> mapOfValuesAndFactors = new Hashtable<Integer, ArrayList<Integer>>();
    private static Integer inputArray[] = { 10, 5, 2, 20 };

    public static void main(String[] args) {

        
        for (int memberOfArray : inputArray) {
            arrayValuesTable.put(memberOfArray, memberOfArray);
        }
        Arrays.sort(inputArray, new IntegerComparator());

        for (int i = 0; i < inputArray.length; i++) {
            cachingTable.clear();
            int numerator = inputArray[i];
           
            for (int j = i + 1; j < inputArray.length; j++) {
            int denominator = inputArray[j];
            
                int remainder = numerator % denominator;
                int quotient  = numerator / denominator;
                
                if (!cachingTable.contains(denominator)) {
                    if (remainder == 0) {

                        if (checkWhetherFactorIsAMemberOfInput(denominator)) {
                            addToCache(denominator);
                            addFactors(numerator, denominator);
                        }

                        if (checkWhetherFactorIsAMemberOfInput(quotient)) {
                            addToCache(quotient);
                            addFactors(numerator, quotient);
                        }

                    }
                }

            }
        }
        
        printMapOfValuesAndFactors();

    }

    private static void addFactors(int number, int factor) {
        ArrayList<Integer> tempList;

        if (mapOfValuesAndFactors.containsKey(number)) {
            tempList = mapOfValuesAndFactors.get(number);
        } else {
            tempList = new ArrayList<Integer>();

        }
        tempList.add(factor);
        mapOfValuesAndFactors.put(number, tempList);
    }

    private static void addToCache(int number) {
        cachingTable.put(number, number);

    }

    private static boolean checkWhetherFactorIsAMemberOfInput(int factor) {
        return arrayValuesTable.containsKey(factor);

    }
    
    private static void printMapOfValuesAndFactors(){
        System.out.print("{");
        for(int key : inputArray){
            System.out.print(key+": "+"[");
            ArrayList<Integer> tempList = mapOfValuesAndFactors.get(key);
            if(tempList!=null && !tempList.isEmpty()){
                for(int values : tempList){
                    System.out.print(values+",");
                } 
            }
            
            System.out.print("],");
        }
        System.out.print("}");
    }

}
