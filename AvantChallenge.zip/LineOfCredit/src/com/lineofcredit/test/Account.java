package com.lineofcredit.test;

import java.util.HashMap;
import java.util.Map;


public class Account{
    private int credit_limit;
    private double available_credit;
    private double balance;
    private double payoff_amount;
    private double apr;
    private double interest;
    private static final int DAYS_IN_YEAR = 365;
    private static final int DAYS_IN_MONTH = 30;
    private int days_owed = 0;
    private int day_withdrawn = 0;
    private int day_paid = 0;
    private boolean last_withdrawl;

    Map<Double, Integer> balance_for_days = new HashMap<Double, Integer>();

    public Account(double credit, double apr) {
        this.available_credit = credit;
        this.apr = apr/100;
    }

    public void withdraw(int amount, int day_withdrawn){
        if(available_credit > amount) {
            if(day_withdrawn != 0) {
                days_owed = day_withdrawn - days_owed;
                balance_for_days.put(balance, days_owed);
            }
            balance = balance + amount;
            available_credit = available_credit - amount;
            this.day_withdrawn = day_withdrawn;
            last_withdrawl = true;
        }
        else{
            System.out.println("You do not have enough credit to perform this transaction.");
        }
    }

    public void make_payment(int amount, int day_paid){
        if(balance >= amount) {
            days_owed = day_paid - day_withdrawn;
            balance_for_days.put(balance, days_owed);
            balance = balance - amount;
            available_credit = available_credit + amount;
            last_withdrawl = false;
            this.day_paid = day_paid;
        }
        else{
            System.out.println("You have paid more than the balance you owe.");
        }
    }

    public double get_payoff_amount(){
       
        if(balance_for_days.isEmpty()) {
            interest = (((balance * apr) / DAYS_IN_YEAR) * DAYS_IN_MONTH);
        }
        else{
            if( last_withdrawl) {
                balance_for_days.put(balance, DAYS_IN_MONTH - day_withdrawn);
            }
            else{
                balance_for_days.put(balance, DAYS_IN_MONTH - day_paid);
            }

            //APR Calculation
            for(Map.Entry<Double, Integer> entry: balance_for_days.entrySet()){
                interest = interest + ((entry.getKey()*apr) / DAYS_IN_YEAR) * entry.getValue();
            }
        }
        payoff_amount = balance + interest;
        // for new month
        days_owed = 0; 
        return payoff_amount;
    }

   
    public int getLimit() {
        return credit_limit;
    }

    public double getAvailable_credit() {
        return available_credit;
    }

    public double getBalance() {
        return balance;
    }

    public double getApr() {
        return apr;
    }

    public double getInterest() {
        return interest;
    }


}
