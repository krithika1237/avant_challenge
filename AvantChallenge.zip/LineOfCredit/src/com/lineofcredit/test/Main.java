package com.lineofcredit.test;

public class Main {

    public static void main(String[] args) {
        Account scenario1 = new Account(1000, 35);
        Account scenario2 = new Account(1000, 35);

        scenario1.withdraw(500, 0);
        System.out.println("Scenario1's amount to be paid is  $" + Math.round(scenario1.get_payoff_amount() * 100.0) / 100.0);
        System.out.println("Scenario1's interest is $" + Math.round(scenario1.getInterest() * 100.0) / 100.0);
        System.out.println();

        scenario2.withdraw(500, 0);
        scenario2.make_payment(200, 15);
        scenario2.withdraw(100, 25);
        System.out.println("Scenario2's amount to be paid is $" + Math.round(scenario2.get_payoff_amount() * 100.0) / 100.0);
        System.out.println("Tom's interest is $" + Math.round(scenario2.getInterest() * 100.0) / 100.0);

    }
}